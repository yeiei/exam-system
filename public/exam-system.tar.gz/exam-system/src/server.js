const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, '..', 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const usersFile = path.join(DATA_DIR, 'users.json');
const recordsFile = path.join(DATA_DIR, 'records.json');
const wrongFile = path.join(DATA_DIR, 'wrong.json');
const questionsFile = path.join(DATA_DIR, 'questions.json');

function loadJson(file, defaultVal = []) {
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf8'));
    }
  } catch (e) {}
  return defaultVal;
}

function saveJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

let users = loadJson(usersFile, []);
let records = loadJson(recordsFile, []);
let wrongQuestions = loadJson(wrongFile, []);
let questions = loadJson(questionsFile, []);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// 根路径返回 index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.use(session({
  secret: 'exam-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.json({ success: false, message: '请填写用户名和密码' });
    }
    
    if (users.find(u => u.username === username)) {
      return res.json({ success: false, message: '用户名已存在' });
    }
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const id = Date.now();
    users.push({ id, username, password: hashedPassword });
    saveJson(usersFile, users);
    
    res.json({ success: true, message: '注册成功' });
  } catch (err) {
    res.json({ success: false, message: '注册失败' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);
    
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.json({ success: false, message: '用户名或密码错误' });
    }
    
    req.session.userId = user.id;
    req.session.username = user.username;
    
    res.json({ success: true, username: user.username });
  } catch (err) {
    res.json({ success: false, message: '登录失败' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  if (req.session.userId) {
    res.json({ loggedIn: true, username: req.session.username });
  } else {
    res.json({ loggedIn: false });
  }
});

app.get('/api/questions', (req, res) => {
  const { count = 50 } = req.query;
  
  if (questions.length === 0) {
    return res.json({ success: false, message: '题库为空，请先导入题库' });
  }
  
  const shuffled = [...questions].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, parseInt(count)).map(q => ({
    id: q.id,
    question_type: q.question_type,
    content: q.content,
    answer: q.answer,
    option_a: q.option_a,
    option_b: q.option_b,
    option_c: q.option_c,
    option_d: q.option_d,
    option_e: q.option_e
  }));
  
  res.json({ success: true, questions: selected });
});

app.post('/api/submit', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  
  const { answers } = req.body;
  const userId = req.session.userId;
  
  let correctCount = 0;
  let wrongCount = 0;
  
  for (const [qId, userAnswer] of Object.entries(answers)) {
    const question = questions.find(q => q.id == qId);
    if (!question) continue;
    
    const userAns = Array.isArray(userAnswer) ? userAnswer.join('') : userAnswer;
    const isCorrect = userAns && userAns.toUpperCase() === question.answer?.toUpperCase();
    
    if (isCorrect) {
      correctCount++;
    } else {
      wrongCount++;
      wrongQuestions.push({
        id: Date.now() + Math.random(),
        user_id: userId,
        question_id: question.id,
        user_answer: userAns || '',
        created_at: new Date().toISOString()
      });
    }
  }
  
  const total = correctCount + wrongCount;
  const score = total > 0 ? Math.round((correctCount / total) * 100) : 0;
  
  records.push({
    id: Date.now(),
    user_id: userId,
    total_questions: total,
    correct_count: correctCount,
    wrong_count: wrongCount,
    score: score,
    exam_time: total * 30,
    created_at: new Date().toISOString()
  });
  
  saveJson(recordsFile, records);
  saveJson(wrongFile, wrongQuestions);
  
  res.json({ success: true, correctCount, wrongCount, score, total });
});

app.get('/api/records', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  
  const userRecords = records
    .filter(r => r.user_id === req.session.userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 20);
  
  res.json({ success: true, records: userRecords });
});

app.get('/api/wrong', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  
  const userWrong = wrongQuestions
    .filter(w => w.user_id === req.session.userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  
  const result = userWrong.map(w => {
    const q = questions.find(q => q.id == w.question_id);
    return {
      wrong_id: w.id,
      user_answer: w.user_answer,
      created_at: w.created_at,
      id: q?.id,
      content: q?.content,
      option_a: q?.option_a,
      option_b: q?.option_b,
      option_c: q?.option_c,
      option_d: q?.option_d,
      answer: q?.answer
    };
  }).filter(r => r.content);
  
  res.json({ success: true, wrongQuestions: result });
});

app.delete('/api/wrong', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  
  wrongQuestions = wrongQuestions.filter(w => w.user_id !== req.session.userId);
  saveJson(wrongFile, wrongQuestions);
  res.json({ success: true });
});

app.get('/api/stats', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  
  const userRecords = records.filter(r => r.user_id === req.session.userId);
  const userWrong = wrongQuestions.filter(w => w.user_id === req.session.userId);
  
  const stats = {
    total_exams: userRecords.length,
    avg_score: userRecords.length > 0 
      ? userRecords.reduce((sum, r) => sum + r.score, 0) / userRecords.length 
      : 0,
    best_score: userRecords.length > 0 
      ? Math.max(...userRecords.map(r => r.score)) 
      : 0,
    total_correct: userRecords.reduce((sum, r) => sum + r.correct_count, 0),
    total_wrong: userRecords.reduce((sum, r) => sum + r.wrong_count, 0),
    wrong_count: userWrong.length
  };
  
  res.json({ success: true, stats });
});

app.listen(PORT, () => {
  console.log('答题系统已启动: http://localhost:' + PORT);
  console.log('题库数量: ' + questions.length + ' 道');
});
